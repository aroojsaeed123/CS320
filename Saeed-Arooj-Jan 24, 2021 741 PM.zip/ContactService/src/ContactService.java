import java.util.Scanner;
import java.io.IOException;


public class ContactService extends Contact{
	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);
		String contact_ID;
		String firstName;
	     String lastName;
	     String phoneNum;
	     String address;
		char answer;
		
		answer = 'Y';
	     
		System.out.print("Enter the contact ID: ");
		contact_ID = scnr.nextLine();
		
	   while (answer != 'N') {
		   try {
			   System.out.print("Enter the First Name: ");
			   firstName = scnr.nextLine();
			   
			   System.out.print("Enter the Last Name: ");
			   lastName = scnr.nextLine();
			   
			   System.out.print("Enter the Phone Number: ");
			   phoneNum = scnr.nextLine();
			   
			   System.out.print("Enter the Address: ");
			   address = scnr.nextLine();
			   }
		   catch(Expection except) {
			   System.out.print("Cannot update file");
		   }
		   System.out.print("\nEnter any key ('N' to quit)");
		   answer= scnr.next().charAt(0);
		   
	   }
		
		
		
		
	}
}


