import java.util.Scanner;



public class Contact{
	public static void main(String[] args ) {
		Scanner scnr= new Scanner(System.in);
         String contact_ID;
		 String firstName;
	     String lastName;
	     String phoneNum;
	     String address;
	     
	     
	     contact_ID = scnr.next();
	     firstName = scnr.next();
	     lastName = scnr.next();
	     phoneNum = scnr.next();
	     address = scnr.next();
	  //Putting the requirements together
	  		//contact id requirements
	  		if(contact_ID == null) {
	  			System.out.println("error ");
	  		}
	  		else if (contact_ID.length()  < 10) {
	  			System.out.println("error ");
	  		}
	  		
	  		//firstName requirements
	  		if(firstName == null) {
	  			System.out.println("error ");
	  		}
	  		else if (firstName.length()  < 10) {
	  			System.out.println("error ");
	  		}
	  		
	  		//lastName requirements
	  		if(lastName == null) {
	  			System.out.println("error ");
	  		}
	  		else if (lastName.length()  < 10) {
	  			System.out.println("error ");
	  		}
	  										
	  		//phoneNum requirements
	  		if(phoneNum == null) {
	  			System.out.println("error ");
	  		}
	  		else if (phoneNum.length()  < 10) {
	  			System.out.println("error ");
	  		}
	  		
	  		//address requirements
	  		if(address == null) {
	  			System.out.println("error ");
	  		}
	  		else if (address.length()  < 10) {
	  			System.out.println("error ");
	  		}
	}
}		
	
