import java.util.Scanner;




public class AppoinmentService extends Appointment{
	public AppoinmentService(String addappoint_ID, String delAppoint_ID, String updateAppoint_ID) {
		super(addappoint_ID, delAppoint_ID, updateAppoint_ID);
		
	}
	Scanner scnr = new Scanner(System.in);
	public String addappoint_ID(){
		System.out.println("Enter the unique ID: ");
		return appoint_ID;
		
	}
	public String delAppoint_ID() {
	     return appoint_ID;
	}
	
	
}
