
public class Appointment {
	protected String appoint_ID;
	public String appointDate ;
	public String appoint_descrip;
	
	
	
	
	public Appointment(String appoint_ID, String appointDate, String descrip, String appoint_descrip) {
		if(appoint_ID == null || appoint_ID.length() > 10) {
			throw new IllegalArgumentException("Error");
		}
		this.appoint_ID = appoint_ID;
		this.appointDate = appointDate;
		this.appoint_descrip = appoint_descrip;
}




	public Appointment(String addappoint_ID, String delAppoint_ID, String updateAppoint_ID) {
		// TODO Auto-generated constructor stub
	}
}
