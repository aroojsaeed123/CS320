import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import main.java.model.Task;

class TaskServiceTest {

	@Test
	void testTaskService() {
		taskService TaskService = new taskService("111", " ", "112");
		assertTrue(taskService.addtask_ID().equals("111"));
		assertTrue(taskService.deltask_ID().equals(" "));
		assertTrue(taskService.updatetask_ID().equals("112"));
	}

}
