package main.java.model;
import java.util.Scanner;


public class TaskService extends Task{
	public TaskService(String addtask_ID, String deltask_ID, String updatetask_ID) {
		super(addtask_ID, deltask_ID, updatetask_ID);
		// TODO Auto-generated constructor stub
		
	}
	Scanner scnr = new Scanner(System.in);
	public String addtask_ID(){
		System.out.println("Enter the unique ID: ");
		return task_ID;
		
	}
	public String deltask_ID() {
	     return task_ID;
	}
	
	public String updatetask_ID() {
		String updatetask_ID = task_ID;
		
		return updatetask_ID;
		
	}
}

	
	
	
		
	
	
	
	