package main.java.model;
import java.util.Scanner;


public class Task{
	protected String task_ID;
	private String name;
	private String descrip;
	Scanner scnr = new Scanner(System.in);
	
	public Task(String task_ID, String name, String descrip) {
		if(task_ID == null || task_ID.length() > 10) {
			throw new IllegalArgumentException("Error");
		}
		this.task_ID = task_ID;
		this.name = name;
		this.descrip = descrip;
	}
	
	public String gettask_ID() {
		return task_ID;
	}
	
	public String getname() {
		return name;
	}
	
	public String getdescrip() {
		return descrip;
	}
	
	
	
	
}