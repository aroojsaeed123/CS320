package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import main.java.model.Task;

class TaskTest {

	@Test
	void testTask() {
	    Task task = new Task("111", "Alex", "This is a correct person");
		assertTrue(task.gettask_ID().equals("111"));
		assertTrue(task.getname().equals("Alex"));
		assertTrue(task.getdescrip().equals("This is a correct person"));
	}
	
	@Test
	void testTask_IDtoolong() {
		Assertions.assertThrows(IllegalArgumentException.class,  () ->{
			new Task("111", "Alex", "This is a correct person");
		});
	}

}
